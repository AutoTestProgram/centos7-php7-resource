// Requires jQuery!
jQuery.ajax({
    url: "https://jira.mongodb.org/s/en_USbc7v3i-1988229788/6109/63/1.4.0-m3/_/download/batch/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector-embededjs/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector-embededjs.js?collectorId=f84b3c75",
    type: "get",
    cache: true,
    dataType: "script"
});


