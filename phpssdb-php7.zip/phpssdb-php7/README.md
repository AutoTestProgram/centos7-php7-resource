
for php7
```
Don't use it for your production env!
```


###wiki
[wiki](https://github.com/jonnywang/phpssdb/wiki)

###contact
更多疑问请+qq群 233415606 or [website http://xingqiba.sinaapp.com](http://xingqiba.sinaapp.com)
